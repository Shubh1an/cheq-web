import { SVG } from "../assets/icons/icons-png";

export const ProfileData = [
  {
    profile_pic: SVG.PROFILE_PIC,
    name: "Joseph Raghuvir",
    designation: "Chief Product Officer",
    company: "Ex-Apple",
  },
  {
    profile_pic: SVG.PROFILE_PIC,
    name: "Joseph Raghuvir",
    designation: "Chief Product Officer",
    company: "Ex-Apple",
  },
  {
    profile_pic: SVG.PROFILE_PIC,
    name: "Joseph Raghuvir",
    designation: "Chief Product Officer",
    company: "Ex-Apple",
  },
  {
    profile_pic: SVG.PROFILE_PIC,
    name: "Joseph Raghuvir",
    designation: "Chief Product Officer",
    company: "Ex-Apple",
  },
  {
    profile_pic: SVG.PROFILE_PIC,
    name: "Joseph Raghuvir",
    designation: "Chief Product Officer",
    company: "Ex-Apple",
  },
  {
    profile_pic: SVG.PROFILE_PIC,
    name: "Joseph Raghuvir",
    designation: "Chief Product Officer",
    company: "Ex-Apple",
  },
];
export const ValueData = [
  {
    image: SVG.OWNER,
    header: "Ownership",
    text: "We act like owners — This is our company. We own the problems .",
  },
  {
    image: SVG.CENTRICITY,
    header: "Customer centricity",
    text: "We act like owners — This is our company. We own the problems .",
  },
  {
    image: SVG.BIAS_ACTION,
    header: "Bias for Action",
    text: "We act like owners — This is our company. We own the problems .",
  },
  {
    image: SVG.TRUST,
    header: "Trust",
    text: "We act like owners — This is our company. We own the problems .",
  },
];
export const JobData = [
  {
    profile_pic: "",
    heading: "Senior Digital Product Designer",
    city: "Banglore",
    content:
      "A product designer is responsible for the design and development of consumer products. Duties of this position include improving existing product designs and...",
  },
  {
    profile_pic: "",
    heading: "Senior Digital Product Designer",
    city: "Banglore",
    content:
      "A product designer is responsible for the design and development of consumer products. Duties of this position include improving existing product designs and...",
  },
  {
    profile_pic: "",
    heading: "Senior Digital Product Designer",
    city: "Banglore",
    content:
      "A product designer is responsible for the design and development of consumer products. Duties of this position include improving existing product designs and...",
  },
  {
    profile_pic: "",
    heading: "Senior Digital Product Designer",
    city: "Banglore",
    content:
      "A product designer is responsible for the design and development of consumer products. Duties of this position include improving existing product designs and...",
  },
  {
    profile_pic: "",
    heading: "Senior Digital Product Designer",
    city: "Banglore",
    content:
      "A product designer is responsible for the design and development of consumer products. Duties of this position include improving existing product designs and...",
  },
  {
    profile_pic: "",
    heading: "Senior Digital Product Designer",
    city: "Banglore",
    content:
      "A product designer is responsible for the design and development of consumer products. Duties of this position include improving existing product designs and...",
  },
  {
    profile_pic: "",
    heading: "Senior Digital Product Designer",
    city: "Banglore",
    content:
      "A product designer is responsible for the design and development of consumer products. Duties of this position include improving existing product designs and...",
  },
];
export const NewsData = [
  { img: SVG.NEWS_ICON1 },
  { img: SVG.NEWS_ICON2 },
  { img: SVG.NEWS_ICON3 },
  { img: SVG.NEWS_ICON4 },
];
